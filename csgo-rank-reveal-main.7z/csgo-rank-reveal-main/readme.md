## info

this is not a cheat, this just utilises the `-netconport` launch option which allows for applications to connect to the game's console and read and send console commands.

using this, i run the `name` and `status` commands to get the players in the current server and parse their rank information on csgostats.gg

## setup

- install the requirements: `pip install -r requirements.txt`
- add the launch option `-netconport 2121` to csgo

## usage

run the python script
